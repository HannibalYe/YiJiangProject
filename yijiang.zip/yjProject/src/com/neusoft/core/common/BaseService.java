package com.neusoft.core.common;

/**
 * 基础服务类
 * 
 * 2014-10-24
 * 
 */
public class BaseService extends BaseObject{

}
